﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodenamesGroupProjectWinForms.Model
{
    public static class Timer
    {
        private static double timer = 90    ;
        private static bool isOn = false;
        public static void startTimer()
        {

        }

        public static void endTimer()
        {

        }

        
    }
}
